/* eslint-disable no-undef */
const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ---------- Theme ----------
function useTheme() {
  const [theme, setTheme] = useState(() => {
    if (typeof window === 'undefined') return 'light';
    return localStorage.getItem('cempura.theme') || 'light';
  });
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark'); else root.classList.remove('dark');
    localStorage.setItem('cempura.theme', theme);
  }, [theme]);
  return [theme, setTheme];
}

function ThemeToggle({ theme, setTheme }) {
  return (
    <div className="font-mono text-[12px] tracking-[0.04em] flex items-center gap-1 select-none"
         style={{ color: 'var(--muted)' }}>
      <button
        onClick={() => setTheme('light')}
        className="px-1.5 py-1 transition-colors"
        style={{ color: theme === 'light' ? 'var(--ink)' : 'var(--muted)' }}
        aria-pressed={theme === 'light'}
      >
        <span className={theme === 'light' ? 'cursor-blink' : ''}>[ light ]</span>
      </button>
      <span style={{ color: 'var(--border)' }}>/</span>
      <button
        onClick={() => setTheme('dark')}
        className="px-1.5 py-1 transition-colors"
        style={{ color: theme === 'dark' ? 'var(--ink)' : 'var(--muted)' }}
        aria-pressed={theme === 'dark'}
      >
        <span className={theme === 'dark' ? 'cursor-blink' : ''}>[ dark ]</span>
      </button>
    </div>
  );
}

// ---------- Logo marks ----------
// Each mark is sized to match the type baseline; paints with currentColor.
const LOGO_MARKS = {
  // 01 — Monogram bracket: terminal-prompt + initials
  bracket: (
    <svg viewBox="0 0 28 28" className="w-7 h-7" aria-hidden="true">
      <path d="M5 6 L2 14 L5 22" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" strokeLinejoin="miter" />
      <path d="M23 6 L26 14 L23 22" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" strokeLinejoin="miter" />
      <text x="14" y="18" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="11" fontWeight="500" fill="currentColor" letterSpacing="0">ac</text>
    </svg>
  ),
  // 02 — Slash AC: editorial slash composition
  slash: (
    <svg viewBox="0 0 28 28" className="w-7 h-7" aria-hidden="true">
      <text x="2" y="20" fontFamily="Fraunces, serif" fontSize="20" fontWeight="300" fill="currentColor" letterSpacing="-0.04em">a</text>
      <line x1="13" y1="24" x2="20" y2="4" stroke="currentColor" strokeWidth="1.25" />
      <text x="18" y="20" fontFamily="Fraunces, serif" fontSize="20" fontWeight="300" fill="currentColor" letterSpacing="-0.04em">c</text>
    </svg>
  ),
  // 03 — Caret prompt: terminal-native, single glyph
  caret: (
    <svg viewBox="0 0 28 28" className="w-7 h-7" aria-hidden="true">
      <text x="14" y="20" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="18" fontWeight="500" fill="currentColor">{'>'}</text>
      <rect x="20" y="14" width="2" height="9" fill="currentColor">
        <animate attributeName="opacity" values="1;1;0;0" keyTimes="0;0.49;0.5;1" dur="1.06s" repeatCount="indefinite" />
      </rect>
    </svg>
  ),
  // 04 — Dot register: Swiss reductive — two dots and a baseline
  register: (
    <svg viewBox="0 0 28 28" className="w-7 h-7" aria-hidden="true">
      <line x1="2" y1="22" x2="26" y2="22" stroke="currentColor" strokeWidth="1" />
      <circle cx="8" cy="14" r="3" fill="currentColor" />
      <circle cx="20" cy="14" r="3" fill="none" stroke="currentColor" strokeWidth="1.25" />
    </svg>
  ),
  // 05 — Editorial A: serif capital with a measured tick
  serifA: (
    <svg viewBox="0 0 28 28" className="w-7 h-7" aria-hidden="true">
      <text x="14" y="22" textAnchor="middle" fontFamily="Fraunces, serif" fontSize="26" fontWeight="300" fill="currentColor" letterSpacing="-0.04em">A</text>
      <line x1="3" y1="26" x2="25" y2="26" stroke="currentColor" strokeWidth="0.75" opacity="0.5" />
    </svg>
  ),
  // 06 — Hash plot: 2x2 dot matrix, ledger-feel
  plot: (
    <svg viewBox="0 0 28 28" className="w-7 h-7" aria-hidden="true">
      <circle cx="9"  cy="11" r="1.6" fill="currentColor" />
      <circle cx="19" cy="11" r="1.6" fill="none" stroke="currentColor" strokeWidth="1" />
      <circle cx="9"  cy="19" r="1.6" fill="none" stroke="currentColor" strokeWidth="1" />
      <circle cx="19" cy="19" r="1.6" fill="currentColor" />
      <line x1="3" y1="25" x2="25" y2="25" stroke="currentColor" strokeWidth="0.75" opacity="0.5" />
    </svg>
  ),
  // 07 — Wordmark only (no glyph)
  none: null,
  // 08 — Original PNG (kept for comparison)
  original: (
    <img src="assets/mark.png" alt="" className="mark w-7 h-7 -my-1" />
  ),
};

function LogoMark({ className = '', variant = 'bracket' }) {
  const mark = LOGO_MARKS[variant] ?? LOGO_MARKS.bracket;
  return (
    <a href="#/" className={`flex items-center gap-2 group ${className}`} style={{ color: 'var(--ink)' }}>
      {mark}
      <span className="font-mono text-[12px] tracking-[0.06em]" style={{ color: 'var(--ink)' }}>
        cempura<span style={{ color: 'var(--muted)' }}>.it</span>
      </span>
    </a>
  );
}

// ---------- Top bar ----------
function TopBar({ theme, setTheme, route, logoVariant }) {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 crumb-blur" style={{ borderBottom: '1px solid var(--border)' }}>
      <div className="max-w-[1280px] mx-auto px-6 md:px-8 h-14 flex items-center justify-between">
        <LogoMark variant={logoVariant} />
        <nav className="flex items-center gap-6">
          {route === 'case' && (
            <a href="#/" className="font-mono text-[12px]" style={{ color: 'var(--muted)' }}>
              <span className="ilink">← back to index</span>
            </a>
          )}
          <ThemeToggle theme={theme} setTheme={setTheme} />
        </nav>
      </div>
    </header>
  );
}

// ---------- Scroll progress line ----------
function ScrollProgress() {
  const ref = useRef(null);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const total = h.scrollHeight - h.clientHeight;
      const pct = total > 0 ? (h.scrollTop / total) * 100 : 0;
      if (ref.current) ref.current.style.width = pct + '%';
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => { window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); };
  }, []);
  return <div ref={ref} className="scroll-progress" />;
}

// ---------- Crosshair tracker ----------
function Crosshair({ enabled }) {
  const hRef = useRef(null);
  const vRef = useRef(null);
  const [coord, setCoord] = useState({ x: 0, y: 0, visible: false });
  useEffect(() => {
    if (!enabled) return;
    const onMove = (e) => {
      if (hRef.current) hRef.current.style.top = e.clientY + 'px';
      if (vRef.current) vRef.current.style.left = e.clientX + 'px';
      setCoord({ x: e.clientX, y: e.clientY, visible: true });
    };
    const onLeave = () => setCoord((c) => ({ ...c, visible: false }));
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseleave', onLeave);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseleave', onLeave); };
  }, [enabled]);
  if (!enabled) return null;
  return (
    <>
      <div ref={hRef} className="crosshair-h" />
      <div ref={vRef} className="crosshair-v" />
      <div className="fixed bottom-3 right-3 z-50 font-mono text-[11px] pointer-events-none"
           style={{ color: 'var(--muted)', opacity: coord.visible ? 1 : 0, transition: 'opacity 200ms ease' }}>
        x:{String(coord.x).padStart(4,'0')}  y:{String(coord.y).padStart(4,'0')}
      </div>
    </>
  );
}

// ---------- Reveal on scroll ----------
function Reveal({ children, as: Tag = 'div', className = '', delay = 0, ...rest }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) { el.classList.add('in'); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          setTimeout(() => el.classList.add('in'), delay);
          io.unobserve(el);
        }
      });
    }, { threshold: 0.12 });
    io.observe(el);
    return () => io.disconnect();
  }, [delay]);
  return <Tag ref={ref} className={`reveal ${className}`} {...rest}>{children}</Tag>;
}

// ---------- Count-up ----------
function CountUp({ to, suffix = '', prefix = '', duration = 1400, decimals = 0 }) {
  const ref = useRef(null);
  const [val, setVal] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) { setVal(to); return; }
    let raf, start;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          const animate = (ts) => {
            if (!start) start = ts;
            const t = Math.min((ts - start) / duration, 1);
            const eased = 1 - Math.pow(1 - t, 3);
            setVal(to * eased);
            if (t < 1) raf = requestAnimationFrame(animate);
          };
          raf = requestAnimationFrame(animate);
          io.unobserve(el);
        }
      });
    }, { threshold: 0.4 });
    io.observe(el);
    return () => { io.disconnect(); if (raf) cancelAnimationFrame(raf); };
  }, [to, duration]);
  const display = decimals > 0 ? val.toFixed(decimals) : Math.round(val);
  return <span ref={ref}>{prefix}{display}{suffix}</span>;
}

// ---------- Terminal hero ----------
function TerminalBoot({ onSettle }) {
  const lines = [
    { kind: 'cmd', text: '$ whoami' },
    { kind: 'out', text: 'artur cempura' },
    { kind: 'out', text: 'engineering lead · ai enablement' },
    { kind: 'out', text: 'krakow / poland · hybrid · remote' },
  ];
  const [shown, setShown] = useState([{ kind: 'cmd', text: '' }]); // typing first line
  const [phase, setPhase] = useState('typing'); // typing → printing → done
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) {
      setShown(lines);
      setPhase('done');
      onSettle && onSettle();
      return;
    }
    let cancelled = false;
    const run = async () => {
      // type first command
      const cmd = lines[0].text;
      for (let i = 1; i <= cmd.length; i++) {
        if (cancelled) return;
        setShown([{ kind: 'cmd', text: cmd.slice(0, i) }]);
        await new Promise((r) => setTimeout(r, 55));
      }
      await new Promise((r) => setTimeout(r, 520));
      setPhase('printing');
      // print following lines
      const next = [{ kind: 'cmd', text: cmd }];
      for (let i = 1; i < lines.length; i++) {
        if (cancelled) return;
        next.push(lines[i]);
        setShown([...next]);
        await new Promise((r) => setTimeout(r, 220));
      }
      await new Promise((r) => setTimeout(r, 280));
      if (cancelled) return;
      setPhase('done');
      onSettle && onSettle();
    };
    run();
    return () => { cancelled = true; };
  }, []);

  return (
    <div className="font-mono text-[12px] leading-[1.65]" style={{ color: 'var(--muted)' }}>
      {shown.map((l, i) => (
        <div key={i}>
          <span style={{ color: l.kind === 'cmd' ? 'var(--ink)' : 'var(--muted)' }}>
            {l.text}
          </span>
          {i === shown.length - 1 && phase !== 'done' && (
            <span className="cursor-blink" />
          )}
        </div>
      ))}
    </div>
  );
}

// ---------- Section header (Swiss ordinal) ----------
function SectionHead({ ord, label, className = '' }) {
  return (
    <div className={`flex items-baseline gap-3 ${className}`}>
      <span className="ord">{ord}</span>
      <span className="font-mono text-[12px] tracking-[0.06em]" style={{ color: 'var(--muted)' }}>
        — {label}
      </span>
    </div>
  );
}

// ---------- Footer ----------
function Footer() {
  return (
    <footer className="border-t" style={{ borderColor: 'var(--border)' }}>
      <div className="max-w-[1280px] mx-auto px-6 md:px-8 py-16 md:py-24">
        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 md:col-span-4">
            <div className="ord mb-4">contact</div>
            <ul className="space-y-2 text-[15px]" style={{ color: 'var(--ink)' }}>
              <li><a className="ilink" href="mailto:artur@cempura.it">artur@cempura.it</a></li>
              <li><a className="ilink" href="https://linkedin.com/in/arturcempura" target="_blank" rel="noreferrer">linkedin.com/in/arturcempura</a></li>
              <li><a className="ilink" href="https://github.com/AC3m" target="_blank" rel="noreferrer">github.com/AC3m</a></li>
            </ul>
          </div>
          <div className="col-span-6 md:col-span-4">
            <div className="ord mb-4">meta</div>
            <ul className="space-y-2 font-mono text-[12px]" style={{ color: 'var(--muted)' }}>
              <li>last updated: 2026-04-28</li>
              <li>version: v2.0</li>
              <li>uptime: 100%</li>
            </ul>
          </div>
          <div className="col-span-6 md:col-span-4">
            <div className="ord mb-4">colophon</div>
            <p className="font-mono text-[12px] leading-[1.7]" style={{ color: 'var(--muted)' }}>
              set in editorial new, inter, berkeley mono · built with next.js, tailwind, framer motion
            </p>
          </div>
        </div>
        <div className="mt-20 pt-6 flex items-center justify-between font-mono text-[12px]"
             style={{ borderTop: '1px solid var(--border)', color: 'var(--muted)' }}>
          <span><span style={{ color: 'var(--ink)' }} className="cursor-blink-signal">$ end_of_line</span></span>
          <span>© 2026 — krakow / pl</span>
        </div>
      </div>
    </footer>
  );
}

// Expose
Object.assign(window, {
  useTheme, ThemeToggle, LogoMark, TopBar, ScrollProgress, Crosshair,
  Reveal, CountUp, TerminalBoot, SectionHead, Footer,
});
