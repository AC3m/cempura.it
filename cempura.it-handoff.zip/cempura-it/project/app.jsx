/* eslint-disable no-undef */
const { useState: useStateA, useEffect: useEffectA } = React;

const TWEAK_DEFAULS = /*EDITMODE-BEGIN*/{
  "headline": "Building the systems\nthat make engineering\nteams faster.",
  "accent": "#B8945C",
  "signal": "#FF3B2F",
  "crosshair": true,
  "displayFont": "Fraunces",
  "logoVariant": "bracket"
}/*EDITMODE-END*/;

function useRoute() {
  const [route, setRoute] = useStateA(() => parseRoute(window.location.hash));
  useEffectA(() => {
    const onHash = () => setRoute(parseRoute(window.location.hash));
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  return route;
}
function parseRoute(hash) {
  if (hash.startsWith('#/case/')) return { name: 'case', slug: hash.slice('#/case/'.length) };
  return { name: 'home' };
}

function App() {
  const [theme, setTheme] = useTheme();
  const route = useRoute();
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULS);

  // Apply tweak-driven CSS vars + font
  useEffectA(() => {
    document.documentElement.style.setProperty('--accent', tweaks.accent);
    document.documentElement.style.setProperty('--signal', tweaks.signal);
    const styleId = '__display_font_override';
    let el = document.getElementById(styleId);
    if (!el) { el = document.createElement('style'); el.id = styleId; document.head.appendChild(el); }
    el.textContent = `.font-display { font-family: '${tweaks.displayFont}', 'Times New Roman', serif !important; }`;
  }, [tweaks.accent, tweaks.signal, tweaks.displayFont]);

  return (
    <>
      <ScrollProgress />
      <Crosshair enabled={!!tweaks.crosshair} />
      <TopBar theme={theme} setTheme={setTheme} route={route.name} logoVariant={tweaks.logoVariant} />

      {route.name === 'case'
        ? <CaseStudy />
        : <Landing tweaks={tweaks} />}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Hero" />
        <TweakText label="Headline" value={tweaks.headline}
                   onChange={(v) => setTweak('headline', v)} />
        <TweakSection label="Color" />
        <TweakColor label="Accent (gold)" value={tweaks.accent}
                    onChange={(v) => setTweak('accent', v)} />
        <TweakColor label="Signal (CTA)" value={tweaks.signal}
                    onChange={(v) => setTweak('signal', v)} />
        <TweakSection label="Type" />
        <TweakSelect label="Display font" value={tweaks.displayFont}
                     onChange={(v) => setTweak('displayFont', v)}
                     options={['Fraunces', 'Playfair Display', 'Cormorant Garamond', 'Söhne Breit']} />
        <TweakSection label="Logo" />
        <TweakSelect label="Mark" value={tweaks.logoVariant}
                     onChange={(v) => setTweak('logoVariant', v)}
                     options={['bracket', 'slash', 'caret', 'register', 'serifA', 'plot', 'none', 'original']} />
        <TweakSection label="Behavior" />
        <TweakToggle label="Crosshair tracker" value={tweaks.crosshair}
                     onChange={(v) => setTweak('crosshair', v)} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
