/* eslint-disable no-undef */
const { useState: useStateL, useEffect: useEffectL, useRef: useRefL } = React;

function Hero({ tweaks }) {
  const [settled, setSettled] = useStateL(false);
  return (
    <section className="relative pt-24 md:pt-32 min-h-[100vh] flex flex-col">
      <div className="max-w-[1280px] w-full mx-auto px-6 md:px-8 flex-1 flex flex-col">
        {/* Terminal layer */}
        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 md:col-span-5">
            <TerminalBoot onSettle={() => setSettled(true)} />
          </div>
          <div className="hidden md:block col-span-7">
            <div className="font-mono text-[11px] flex justify-end gap-6" style={{ color: 'var(--muted)' }}>
              <span>lat 50.0647° n</span>
              <span>lon 19.9450° e</span>
              <span>tz utc+2</span>
            </div>
          </div>
        </div>

        {/* Display headline */}
        <div className={`mt-16 md:mt-24 transition-opacity duration-700 ${settled ? 'opacity-100' : 'opacity-0'}`}>
          <h1 className="font-display font-light leading-[0.95]"
              style={{ fontSize: 'clamp(44px, 8vw, 132px)', color: 'var(--ink)' }}>
            {tweaks.headline.split('\n').map((line, i) => (
              <span key={i} className="block">
                {line}
              </span>
            ))}
          </h1>
        </div>

        <div className={`mt-10 md:mt-14 grid grid-cols-12 gap-6 transition-opacity duration-700 delay-200 ${settled ? 'opacity-100' : 'opacity-0'}`}>
          <p className="col-span-12 md:col-span-7 text-[17px] md:text-[19px] leading-[1.5]"
             style={{ color: 'var(--muted)' }}>
            <span style={{ color: 'var(--ink)' }}>AI-assisted delivery, internal tooling, and team scaling</span> — for organizations that want results, not roadmaps.
          </p>
          <div className="col-span-12 md:col-span-5 flex md:justify-end items-end gap-3 flex-wrap">
            <a href="#/case/ai-adoption" className="btn-bracket">
              [ view case study <span className="arrow">→</span> ]
            </a>
            <a href="#synek" className="btn-bracket">
              [ see SYNEK <span className="arrow">↗</span> ]
            </a>
          </div>
        </div>

        {/* Scroll cue */}
        <div className="mt-auto pt-16 pb-8 flex items-end justify-between font-mono text-[11px]"
             style={{ color: 'var(--muted)' }}>
          <span>↓ scroll · 04 sections</span>
          <span>{new Date().toISOString().slice(0,10)} · session.live</span>
        </div>
      </div>
    </section>
  );
}

function SynekSection() {
  const visualRef = useRefL(null);
  useEffectL(() => {
    const el = visualRef.current;
    if (!el) return;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) return;
    const onScroll = () => {
      const rect = el.getBoundingClientRect();
      const mid = window.innerHeight / 2;
      const delta = (rect.top + rect.height / 2 - mid) / window.innerHeight; // -0.5..0.5
      el.style.transform = `translateY(${(-delta * 16).toFixed(2)}px)`;
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <section id="synek" className="py-[96px] md:py-[160px] border-t" style={{ borderColor: 'var(--border)' }}>
      <div className="max-w-[1280px] mx-auto px-6 md:px-8">
        <Reveal>
          <SectionHead ord="01" label="featured / live project" className="mb-12 md:mb-16" />
        </Reveal>
        <div className="grid grid-cols-12 gap-6 md:gap-8 items-start">
          <Reveal className="col-span-12 md:col-span-5">
            <div className="font-mono text-[11px] mb-6" style={{ color: 'var(--accent)' }}>
              ● live · synek.app
            </div>
            <h2 className="font-display font-light text-[64px] md:text-[88px] leading-[0.95] mb-6"
                style={{ color: 'var(--ink)' }}>
              SYNEK
            </h2>
            <p className="text-[17px] leading-[1.55] mb-8 max-w-[44ch]" style={{ color: 'var(--muted)' }}>
              <span style={{ color: 'var(--ink)' }}>A side project for coaches and athletes</span> — replacing spreadsheets and manual Strava copy-paste with a single, opinionated workspace.
            </p>
            <div className="flex flex-wrap gap-2 mb-10">
              {['Next.js', 'Supabase', 'Vercel', 'Claude Code'].map((s) => (
                <span key={s} className="chip">{s}</span>
              ))}
            </div>
            <div className="flex flex-col gap-3 font-mono text-[12px] mb-8" style={{ color: 'var(--muted)' }}>
              <div className="flex justify-between"><span>founded</span><span style={{ color: 'var(--ink)' }}>2024</span></div>
              <div className="flex justify-between"><span>role</span><span style={{ color: 'var(--ink)' }}>solo · design + build</span></div>
              <div className="flex justify-between"><span>stage</span><span style={{ color: 'var(--ink)' }}>private beta</span></div>
            </div>
            <a href="#" className="btn-bracket">[ visit <span className="arrow">↗</span> ]</a>
          </Reveal>

          <Reveal className="col-span-12 md:col-span-7" delay={120}>
            <div ref={visualRef} className="ph-rect aspect-[16/10] w-full relative will-change-transform">
              <div className="absolute top-3 left-3 font-mono text-[10px]" style={{ color: 'var(--muted)' }}>
                synek_preview.png · 1600×1000
              </div>
              <div className="absolute bottom-3 right-3 font-mono text-[10px]" style={{ color: 'var(--accent)' }}>
                ⌘ + k · search
              </div>
              {/* Faux UI hint */}
              <div className="absolute inset-x-10 top-16 bottom-12 grid grid-cols-12 gap-3 opacity-40">
                <div className="col-span-3 border" style={{ borderColor: 'var(--border)' }} />
                <div className="col-span-9 grid grid-rows-6 gap-3">
                  <div className="row-span-2 border" style={{ borderColor: 'var(--border)' }} />
                  <div className="row-span-4 border" style={{ borderColor: 'var(--border)' }} />
                </div>
              </div>
            </div>
            <div className="mt-3 flex justify-between font-mono text-[11px]" style={{ color: 'var(--muted)' }}>
              <span>fig.01 — workspace shell</span>
              <span>parallax · 8px</span>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function CaseCards() {
  const cards = [
    { num: '01', title: '0 to ~85% AI-assisted\ndelivery adoption', meta: '2025 · betting · eng lead', summary: 'Took a 9-person engineering team from zero baseline to ~85% measured AI adoption in two quarters.', active: true, href: '#/case/ai-adoption' },
    { num: '02', title: '120+ stale flags deleted\nin days, not weeks', meta: '2024 · platform · eng lead', summary: 'Built a feature-flag audit pipeline. Cleared a 4-year backlog of dead toggles in under a week.', active: false, href: '#' },
    { num: '03', title: 'Shared Codex workflows\nfor a 9-person team', meta: '2025 · tooling · eng lead', summary: 'Codified prompts, review patterns, and CLI scaffolds so every engineer started Monday from the same baseline.', active: false, href: '#' },
  ];
  return (
    <section id="case-studies" className="py-[96px] md:py-[160px] border-t" style={{ borderColor: 'var(--border)' }}>
      <div className="max-w-[1280px] mx-auto px-6 md:px-8">
        <Reveal>
          <div className="flex items-end justify-between mb-12 md:mb-16">
            <SectionHead ord="02" label="case studies" />
            <span className="font-mono text-[11px]" style={{ color: 'var(--muted)' }}>03 entries · 1 published</span>
          </div>
        </Reveal>
        <div className="grid grid-cols-12 gap-6 md:gap-6">
          {cards.map((c, i) => (
            <Reveal key={c.num} className="col-span-12 md:col-span-4" delay={i * 80}>
              <a
                href={c.active ? c.href : undefined}
                className={`case-card block h-full p-6 md:p-7 ${c.active ? 'active cursor-pointer' : 'cursor-not-allowed'}`}
                style={{
                  border: '1px solid var(--border)',
                  background: 'var(--surface)',
                  opacity: c.active ? 1 : 0.55,
                }}
                aria-disabled={!c.active}
              >
                <div className="flex items-start justify-between mb-10">
                  <div className="font-display font-light text-[64px] leading-none" style={{ color: 'var(--accent)' }}>{c.num}</div>
                  <div className="font-mono text-[10px] mt-2" style={{ color: 'var(--muted)' }}>
                    {c.active ? '● published' : '○ coming soon'}
                  </div>
                </div>
                <h3 className="font-display font-light text-[26px] leading-[1.08] mb-4 whitespace-pre-line"
                    style={{ color: 'var(--ink)' }}>
                  {c.title}
                </h3>
                <p className="text-[14px] leading-[1.55] mb-8" style={{ color: 'var(--muted)' }}>
                  {c.summary}
                </p>
                <div className="font-mono text-[11px] mb-8 pt-4" style={{ color: 'var(--muted)', borderTop: '1px solid var(--border)' }}>
                  {c.meta}
                </div>
                <div className="font-mono text-[12px] inline-flex flex-col gap-1"
                     style={{ color: c.active ? 'var(--ink)' : 'var(--muted)' }}>
                  <span>{c.active ? '[ read → ]' : '[ coming soon ]'}</span>
                  <span className="read-underline" />
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function PositioningStrip() {
  return (
    <section className="py-[96px] md:py-[160px] border-t" style={{ borderColor: 'var(--border)' }}>
      <div className="max-w-[1280px] mx-auto px-6 md:px-8">
        <Reveal>
          <SectionHead ord="03" label="positioning" className="mb-12 md:mb-16" />
        </Reveal>
        <div className="grid grid-cols-12 gap-6">
          <Reveal className="col-span-12 md:col-span-8 md:col-start-3">
            <p className="font-display font-light leading-[1.08] tracking-[-0.025em]"
               style={{ fontSize: 'clamp(28px, 4.4vw, 56px)', color: 'var(--ink)' }}>
              Ten-plus years across software, product, and operations in <em style={{ fontStyle: 'italic', color: 'var(--accent)' }}>regulated, high-traffic betting</em>. Hands-on with AI-assisted delivery, internal tooling, automation, and workflow design.
            </p>
            <p className="mt-10 font-mono text-[13px]" style={{ color: 'var(--muted)' }}>
              ↳ building over advising · prototypes over decks
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Landing({ tweaks }) {
  return (
    <main>
      <Hero tweaks={tweaks} />
      <SynekSection />
      <CaseCards />
      <PositioningStrip />
      <Footer />
    </main>
  );
}

Object.assign(window, { Landing });
