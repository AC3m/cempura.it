/* eslint-disable no-undef */
const { useEffect: useEffectC } = React;

function Crumb() {
  return (
    <div className="sticky top-14 z-30 crumb-blur" style={{ borderBottom: '1px solid var(--border)' }}>
      <div className="max-w-[1280px] mx-auto px-6 md:px-8 h-10 flex items-center justify-between font-mono text-[12px]"
           style={{ color: 'var(--muted)' }}>
        <span><span style={{ color: 'var(--ink)' }}>$</span> cd ~/case-studies/ai-adoption</span>
        <span className="hidden md:inline">case 01 · 2025 · evoke plc</span>
      </div>
    </div>
  );
}

function CaseStudy() {
  useEffectC(() => { window.scrollTo(0, 0); }, []);
  return (
    <main>
      <Crumb />

      {/* Hero */}
      <section className="pt-16 md:pt-24 pb-[96px] md:pb-[160px]">
        <div className="max-w-[1280px] mx-auto px-6 md:px-8">
          <div className="grid grid-cols-12 gap-6">
            <div className="col-span-12 md:col-span-2">
              <div className="font-display font-light text-[80px] leading-none" style={{ color: 'var(--accent)' }}>01</div>
            </div>
            <div className="col-span-12 md:col-span-10">
              <div className="font-mono text-[12px] mb-6 flex flex-wrap gap-x-4 gap-y-1"
                   style={{ color: 'var(--muted)' }}>
                <span>2025</span><span>·</span>
                <span>evoke plc</span><span>·</span>
                <span>engineering lead</span><span>·</span>
                <span>9-person team</span><span>·</span>
                <span>typescript / react</span>
              </div>
              <h1 className="font-display font-light leading-[0.95] tracking-[-0.035em]"
                  style={{ fontSize: 'clamp(44px, 7vw, 112px)', color: 'var(--ink)' }}>
                0 to ~85%<br/>AI-assisted<br/>delivery adoption.
              </h1>
              <p className="mt-10 max-w-[60ch] text-[17px] md:text-[19px] leading-[1.55]"
                 style={{ color: 'var(--muted)' }}>
                Two quarters. Nine engineers. One internal dashboard that turned a vibe into a baseline — and a baseline into a habit.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Problem */}
      <section className="py-[96px] md:py-[160px] border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-[1280px] mx-auto px-6 md:px-8">
          <Reveal>
            <SectionHead ord="01" label="problem" className="mb-12" />
          </Reveal>
          <Reveal>
            <p className="pull max-w-[22ch] mx-auto md:mx-0"
               style={{ fontSize: 'clamp(36px, 5.6vw, 84px)', color: 'var(--ink)' }}>
              Jira and GitLab couldn't show <span style={{ color: 'var(--accent)' }}>AI usage.</span> The team had no shared baseline.
            </p>
          </Reveal>
          <Reveal delay={120}>
            <div className="mt-16 grid grid-cols-12 gap-6">
              <div className="col-span-12 md:col-span-6 md:col-start-7">
                <p className="text-[16px] leading-[1.7]" style={{ color: 'var(--muted)' }}>
                  Anecdotes everywhere. <span style={{ color: 'var(--ink)' }}>Some engineers had Copilot pinned, others wouldn't touch it.</span> Leadership wanted a number. The team wanted to be left alone. Neither group had what they needed: a shared, honest picture of where AI was actually moving the work.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Approach */}
      <section className="py-[96px] md:py-[160px] border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-[1280px] mx-auto px-6 md:px-8">
          <Reveal>
            <SectionHead ord="02" label="approach" className="mb-12" />
          </Reveal>
          <div className="grid grid-cols-12 gap-6">
            <Reveal className="col-span-12 md:col-span-4">
              <h2 className="font-display font-light leading-[1] tracking-[-0.03em]"
                  style={{ fontSize: 'clamp(32px, 4.2vw, 56px)', color: 'var(--ink)' }}>
                Build the dashboard nobody asked for.
              </h2>
            </Reveal>
            <div className="col-span-12 md:col-span-7 md:col-start-6">
              {[
                { n: '01', t: 'Internal dashboard, two weeks.', d: 'Stitched GitLab, Jira, and IDE telemetry into a single team view. Owned the schema; owned the read path.' },
                { n: '02', t: 'DORA + AI-usage metrics, side-by-side.', d: 'Lead time, deploy frequency, and AI-assist rate on the same chart — so quality and speed couldn\'t be argued in isolation.' },
                { n: '03', t: 'Surfaced gaps weekly, not quarterly.', d: 'A 10-minute Friday review. Names off, patterns on. Trends visible before they became culture.' },
                { n: '04', t: 'Shared prompts, not policies.', d: 'A small library of prompts and review checklists, versioned in the repo. Suggestions, not mandates.' },
              ].map((s, i) => (
                <Reveal key={s.n} delay={i * 80}>
                  <div className="grid grid-cols-12 gap-4 py-6"
                       style={{ borderTop: '1px solid var(--border)' }}>
                    <div className="col-span-2 md:col-span-1 font-mono text-[12px] pt-1" style={{ color: 'var(--accent)' }}>{s.n}</div>
                    <div className="col-span-10 md:col-span-11">
                      <h3 className="font-display font-light text-[24px] md:text-[28px] leading-[1.15] mb-2"
                          style={{ color: 'var(--ink)' }}>{s.t}</h3>
                      <p className="text-[15px] leading-[1.6]" style={{ color: 'var(--muted)' }}>{s.d}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
              <div className="py-6" style={{ borderTop: '1px solid var(--border)' }} />
            </div>
          </div>
        </div>
      </section>

      {/* Outcome */}
      <section className="py-[96px] md:py-[160px] border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-[1280px] mx-auto px-6 md:px-8">
          <Reveal>
            <SectionHead ord="03" label="outcome" className="mb-12 md:mb-16" />
          </Reveal>
          <div className="grid grid-cols-12 gap-8 md:gap-6">
            {[
              { big: <><CountUp to={0} duration={400} /> → ~<CountUp to={85} duration={1600} suffix="%" /></>, label: 'measured AI-assisted delivery' },
              { big: <><CountUp to={9} duration={1000} /></>, label: 'engineers, fully aligned' },
              { big: <><CountUp to={0} duration={1000} suffix="%" /></>, label: 'attrition during rollout' },
            ].map((m, i) => (
              <Reveal key={i} className="col-span-12 md:col-span-4" delay={i * 120}>
                <div className="num-callout" style={{ fontSize: 'clamp(72px, 10vw, 144px)' }}>{m.big}</div>
                <div className="mt-6 font-mono text-[12px]" style={{ color: 'var(--muted)' }}>{m.label}</div>
              </Reveal>
            ))}
          </div>
          <Reveal delay={300}>
            <p className="mt-20 max-w-[58ch] text-[17px] leading-[1.6]" style={{ color: 'var(--muted)' }}>
              <span style={{ color: 'var(--ink)' }}>The dashboard didn't change the team — the conversation it forced did.</span> Once the number was visible, debate moved from "should we" to "where next." Adoption stopped being a top-down ask and became a peer signal.
            </p>
          </Reveal>
        </div>
      </section>

      {/* What I'd do differently */}
      <section className="py-[96px] md:py-[160px] border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-[1280px] mx-auto px-6 md:px-8">
          <Reveal>
            <SectionHead ord="04" label="what i'd do differently" className="mb-10" />
          </Reveal>
          <div className="grid grid-cols-12 gap-6">
            <Reveal className="col-span-12 md:col-span-7">
              <ul className="space-y-5 text-[15px] leading-[1.65]" style={{ color: 'var(--muted)' }}>
                <li className="flex gap-4"><span className="font-mono text-[11px] pt-1.5" style={{ color: 'var(--accent)' }}>—</span><span><span style={{ color: 'var(--ink)' }}>Ship the metric before the dashboard.</span> A spreadsheet for two weeks would've validated the signal faster than a polished UI.</span></li>
                <li className="flex gap-4"><span className="font-mono text-[11px] pt-1.5" style={{ color: 'var(--accent)' }}>—</span><span><span style={{ color: 'var(--ink)' }}>Define "AI-assisted" earlier.</span> The first month was spent re-litigating what counted. A loose, public definition would've moved faster than a perfect one.</span></li>
                <li className="flex gap-4"><span className="font-mono text-[11px] pt-1.5" style={{ color: 'var(--accent)' }}>—</span><span><span style={{ color: 'var(--ink)' }}>Bring product in from week one.</span> Engineering moved first. By the time PM noticed the velocity shift, scope had already absorbed the gain.</span></li>
              </ul>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Prev / next */}
      <section className="py-16 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-[1280px] mx-auto px-6 md:px-8">
          <div className="grid grid-cols-12 gap-6">
            <div className="col-span-12 md:col-span-4 opacity-40">
              <div className="ord mb-2">prev · 02</div>
              <div className="font-display text-[22px] leading-[1.15]" style={{ color: 'var(--ink)' }}>Stale flag cleanup</div>
              <div className="font-mono text-[11px] mt-2" style={{ color: 'var(--muted)' }}>[ coming soon ]</div>
            </div>
            <div className="col-span-12 md:col-span-4 text-center">
              <a href="#/" className="btn-bracket">[ ← return to index ]</a>
            </div>
            <div className="col-span-12 md:col-span-4 md:text-right opacity-40">
              <div className="ord mb-2">next · 03</div>
              <div className="font-display text-[22px] leading-[1.15]" style={{ color: 'var(--ink)' }}>Shared codex workflows</div>
              <div className="font-mono text-[11px] mt-2" style={{ color: 'var(--muted)' }}>[ coming soon ]</div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}

Object.assign(window, { CaseStudy });
